import SwiftUI

public struct ProgressBar: View {
    var fillIn: Int
    public var body: some View {
        HStack(spacing: 0) {
            ZStack {
                Circle()
                    .fill(fillIn >= 1 ? Color.blue : Color.blue.opacity(0.3))
                    .frame(width: 40)
                Image(systemName: "checkmark")
                    .foregroundColor(fillIn >= 1 ? Color.white : Color.white.opacity(0))
            }
            .rotation3DEffect(
                .degrees(fillIn == 1 ? 360 : 0),
                axis: (x: 1.0, y: 0.0, z: 0.0)
                )
            Rectangle()
                .fill(fillIn >= 1 ? Color.blue : Color.blue.opacity(0.5))
                .frame(height: 5)
            ZStack {
                Circle()
                    .fill(fillIn >= 2 ? Color.blue : Color.blue.opacity(0.3))
                    .frame(width: 40)
                Image(systemName: "checkmark")
                    .foregroundColor(fillIn >= 2 ? Color.white : Color.white.opacity(0))
            }
            .rotation3DEffect(
                .degrees(fillIn == 2 ? 360 : 0),
                axis: (x: 1.0, y: 1.0, z: 0.0)
                )
            Rectangle()
                .fill(fillIn >= 2 ? Color.blue : Color.blue.opacity(0.5))
                .frame(height: 5)
            ZStack {
                Circle()
                    .fill(fillIn >= 3 ? Color.blue : Color.blue.opacity(0.3))
                    .frame(width: 40)
                Image(systemName: "checkmark")
                    .foregroundColor(fillIn >= 3 ? Color.white : Color.white.opacity(0))
            }
            .rotation3DEffect(
                .degrees(fillIn == 3 ? 360 : 0),
                axis: (x: 1.0, y: 1.0, z: 0.0)
                )
        }
        .animation(.spring())
        .shadow(color: .gray, radius: 3, x: 1, y: 2)
        .frame(width: UIScreen.main.bounds.width - 100, height: 100)
    
    }
}
