import SwiftUI

public struct MCQView: View {
    @State private var correctChoiceIndex = -1
    @State private var userSelctedCorrectChoiceIndexes = [Int]()
    @State private var currentIndex = 0
    let prompts: [MCQPrompt]
    @Binding var showNextCategory: Bool
    public var body: some View {
            VStack(spacing: 40) {
                ProgressBar(fillIn: userSelctedCorrectChoiceIndexes.count)
                Text(prompts[currentIndex].prompt)
                    .font(.title2)
                    .bold()
                    .fixedSize(horizontal: false, vertical: true)
                
                VStack(spacing: 20) {
                    ForEach(0..<prompts[currentIndex].choices.count) { choiceIndex in
                        Button(action: {
                            correctChoiceIndex = -1
                            withAnimation(.spring()) {
                                if isCorrect(choice: prompts[currentIndex].choices[choiceIndex]) {
                                    if userSelctedCorrectChoiceIndexes.contains(choiceIndex) == false {
                                        correctChoiceIndex = choiceIndex
                                        userSelctedCorrectChoiceIndexes.append(choiceIndex)
                                    }
                                }}
                        }) {
                            CustomButton(colors: userSelctedCorrectChoiceIndexes.contains(choiceIndex) ? [Color.darkGreen, Color.lightGreen]  :
                                            [Color.darkBlue, Color.lightBlue], withFixedFrame: true) {
                                Text(prompts[currentIndex].choices[choiceIndex])
                            }
                            
                        }
                        .rotation3DEffect(
                            .degrees(correctChoiceIndex == choiceIndex ? 360 : 0),
                            axis: (x: 1.0, y: 0.0, z: 0.0)
                        )
                        .allowsHitTesting(userSelctedCorrectChoiceIndexes.contains(choiceIndex) == false)
                    }
                }
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {
                            withAnimation {
                                if currentIndex < (prompts.count - 1) {
                                    currentIndex += 1
                                    userSelctedCorrectChoiceIndexes = []
                                } else {
                                    showNextCategory = true
                                }}}) {
                        CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                            Text("Next")
                        }
                    }
                }
            }
            .padding()
    }
    
    private func isCorrect(choice: String) -> Bool {
        let symptomPrompt = prompts[currentIndex]
        if symptomPrompt.correctChoices.contains(choice) {
            return true
        } else {
            return false
        }
    }
    
}
