import SwiftUI



public struct CustomButton<Content: View>: View {
    let content: () -> Content
    let colors: [Color]
    let withFixedFrame: Bool
    public var body: some View {
        content()
            .font(.headline)
            .foregroundColor(.white)
            .padding()
            .frame(width: withFixedFrame ? 350 : nil)
            .background(LinearGradient(gradient: Gradient(colors: colors), startPoint: .leading, endPoint: .trailing))
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .shadow(color: .gray, radius: 4, x: 1, y: 3)
        
    }
    public init(colors: [Color], withFixedFrame: Bool = false, @ViewBuilder content: @escaping () -> Content) {
        self.content = content
        self.colors = colors
        self.withFixedFrame = withFixedFrame
    }
}
