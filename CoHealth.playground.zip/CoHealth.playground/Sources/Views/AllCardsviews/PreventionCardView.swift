
import SwiftUI

public struct PreventionView: View {
    @State private var userAllowed = false
    @State private var showWhatAfterVaccinationView = false
    public var body: some View {
        Group {
            if userAllowed == false {
                CardInfo(userAllowed: $userAllowed, info: "Select the appropriate choices about prevention of COVID-19")
            } else {
                VStack {
                    MCQView(prompts: Database.preventionPrompts, showNextCategory: $showWhatAfterVaccinationView)
                    NavigationLink(
                        destination: WhatAfterVaccinationView(),
                        isActive: $showWhatAfterVaccinationView) {
                        EmptyView()
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}
