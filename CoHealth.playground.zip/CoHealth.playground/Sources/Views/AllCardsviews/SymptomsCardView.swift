import SwiftUI

public struct SymptomsView: View {
    @State private var userAllowed = false
    @State private var showPreventionView = false
    public var body: some View {
        Group {
            if userAllowed == false {
                CardInfo(userAllowed: $userAllowed, info: "Select the appropriate choices about symptoms of COVID-19")
            } else {
                VStack {
                    MCQView(prompts: Database.symptomPrompts, showNextCategory: $showPreventionView)
                    NavigationLink(
                        destination: PreventionView(),
                        isActive: $showPreventionView) {
                        EmptyView()
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}
