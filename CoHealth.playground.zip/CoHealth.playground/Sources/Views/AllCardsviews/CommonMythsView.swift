import SwiftUI

public struct CommonMythsView: View {
    @State private var userAllowed = false
    @State private var cards: [Card] = Database.mythCards
    public var body: some View {
        Group {
            if userAllowed == false {
                CardInfo(userAllowed: $userAllowed, info: "Sort the cards according to MYTHS and FACTS by swiping left or right")
            } else {
                ZStack {
                    Image(uiImage: UIImage(named: "mythsbackground.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                    VStack(spacing: 50) {
                        Text("Sort the cards by swiping left or right")
                            .font(.title)
                        ZStack {
                            ForEach(0..<cards.count, id: \.self) { index in
                                CommonMythsCardView(card: self.cards[index]) {
                                   withAnimation {
                                       self.removeCard(at: index)
                                   }
                                }
                                .stacked(at: index, in: self.cards.count)
                                .allowsHitTesting(index == self.cards.count - 1)
                            }
                        }
                        if cards.isEmpty {
                            Button(action: {
                                withAnimation {
                                    resetCards()
                                }
                            }, label: {
                                CustomButton(colors: [Color.darkGreen, Color.lightGreen]) {
                                    HStack(spacing: 20) {
                                        Text("Start Again")
                                        Image(uiImage: UIImage(named: "restart.png")!)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 25)
                                    }
                                }
                            })
                        }
                        VStack {
                            Spacer()
                            HStack {
                                CustomButton(colors: [Color.darkRed, Color.lightRed]) {
                                    HStack(spacing: 20) {
                                        Image(systemName: "arrow.left")
                                        Text("MYTH")
                                    }
                                }
                                Spacer()
                                CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                                    HStack(spacing: 20) {
                                        Text("FACT")
                                        Image(systemName: "arrow.right")
                                    }
                                }
                            }
                            .frame(width: 550)
                            HStack {
                                Spacer()
                                NavigationLink(
                                    destination: SymptomsView(),
                                    label: {
                                        CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                                            HStack(spacing: 20) {
                                                Text("Go On")
                                                Image(systemName: "arrow.right")
                                            }
                                        }
                                    })
                            }
                            .frame(width: 580)
                            .padding(.vertical)
                        }
                        
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
    public init() {}
    
    func removeCard(at index: Int) {
        cards.remove(at: index)
    }
    
    func resetCards() {
        cards = Database.mythCards
    }
}

public struct CommonMythsCardView: View {
    let card: Card
    var removal: (() -> Void)? = nil

    @State private var offset = CGSize.zero
    public var body: some View {
    ZStack {
        RoundedRectangle(cornerRadius: 25, style: .continuous)
            .fill(
                Color.white
                    .opacity(1 - Double(abs(offset.width / 50)))
            )
            .background(
                RoundedRectangle(cornerRadius: 25, style: .continuous)
                    .fill(offset.width > 0 ? Color.green : Color.red)
            )
            .shadow(radius: 10)

        VStack {
            Text(card.prompt)
                .font(.largeTitle)
                .foregroundColor(.black)
        }
        .padding(20)
        .multilineTextAlignment(.center)
    }
    .frame(width: 450, height: 250)
//        .frame(width: 350, height: 200)
    .rotationEffect(.degrees(Double(offset.width / 5)))
    .offset(x: offset.width * 5, y: 0)
    .opacity(2 - Double(abs(offset.width / 50)))
    .gesture(
        DragGesture()
            .onChanged { gesture in
                self.offset = gesture.translation
            }
            .onEnded { _ in
                if (abs(offset.width) > 100) && ((offset.width > 100 && isFact()) || (offset.width < -100 && isMyth())) {
                    removal?()
                } else {
                    withAnimation(.spring()) {
                        offset = .zero
                    }
                }
            }
    )    }
    
    func isMyth() -> Bool {
        if card.answer == .myth {
            return true
        } else {
            return false
        }
    }
    func isFact() -> Bool {
        if card.answer == .fact {
            return true
        } else {
            return false
        }
    }
    
}
