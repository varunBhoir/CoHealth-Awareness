import SwiftUI

public struct WhatAfterVaccinationView: View {
    @State private var userAllowed = false
    @State private var cards: [Card] = Database.afterVaccinationCards
    public var body: some View {
        Group {
            if userAllowed == false {
                CardInfo(userAllowed: $userAllowed, info: "Sort the cards according to appropriate norms we have to follow after vaccination")
            } else  {
                ZStack {
                    Image(uiImage: UIImage(named: "mythsbackground.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                    VStack(spacing: 50) {
                        Text("Sort the cards by swiping left or right")
                            .font(.title)
                        ZStack {
                            ForEach(0..<cards.count, id: \.self) { index in
                                CommonMythsCardView(card: self.cards[index]) {
                                   withAnimation {
                                       self.removeCard(at: index)
                                   }
                                }
                                .stacked(at: index, in: self.cards.count)
                                .allowsHitTesting(index == self.cards.count - 1)
                            }
                        }
                        if cards.isEmpty {
                            Button(action: {
                                withAnimation {
                                    resetCards()
                                }
                            }, label: {
                                CustomButton(colors: [Color.darkGreen, Color.lightGreen]) {
                                    HStack(spacing: 20) {
                                        Text("Start Again")
                                        Image(uiImage: UIImage(named: "restart.png")!)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 25)
                                    }
                                }
                            })
                        }
                        VStack {
                            Spacer()
                            HStack {
                                CustomButton(colors: [Color.darkRed, Color.lightRed]) {
                                    HStack(spacing: 20) {
                                        Image(systemName: "arrow.left")
                                        Text("NO")
                                    }
                                }
                                Spacer()
                                CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                                    HStack(spacing: 20) {
                                        Text("YES")
                                        Image(systemName: "arrow.right")
                                    }
                                }
                            }
                            .frame(width: 550)
                            HStack {
                                Spacer()
                                NavigationLink(
                                    destination: HandWashingView(),
                                    label: {
                                        CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                                            HStack(spacing: 20) {
                                                Text("Go On")
                                                Image(systemName: "arrow.right")
                                            }
                                        }
                                    })
                            }
                            .frame(width: 580)
                            .padding(.vertical)
                        }
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
    public init() {}
    
    func removeCard(at index: Int) {
        cards.remove(at: index)
    }
    
    func resetCards() {
        cards = Database.afterVaccinationCards
    }
}
