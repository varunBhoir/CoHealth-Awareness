import SwiftUI

public struct CardInfo: View {
    @Binding var userAllowed: Bool
    let info: String
    public var body: some View {
        VStack {
            Text(info)
                .font(.title)
            Spacer()
            HStack {
                Spacer()
                Button(action: {
                    withAnimation {
                        userAllowed = true
                    }
                }, label: {
                    CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                        Text("Go on")
                    }
                })
            }
        }
        .padding()
    }
}

