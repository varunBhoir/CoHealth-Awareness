import SwiftUI

public struct HandWashingView: View {
    @State private var imageName = "handwashing.png"
    @State private var timeRemaning = 20
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State private var showJustWashedButton = false
    @State private var showClimaxView = false
    public var body: some View {
        VStack(spacing: 10) {
            Text("#BreakTheCoronaOutbreak")
                .font(.title)
            Text("We will wait for you")
                .font(.title2)
            Image(uiImage: UIImage(named: imageName)!)
                .resizable()
                .scaledToFit()
                .clipShape(Circle())
                .frame(width: 200)
                .overlay(Circle().stroke(Color.white, lineWidth: 5).shadow(color: .gray, radius: 5))
                .padding()
            Text("00: \(timeRemaning)")
                .font(.title)
            Spacer()
            if showJustWashedButton {
                CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                    Text("I just washed, go ahead")
                }
                .onTapGesture {
                    // stop the timer
                    timer.upstream.connect().cancel()
                    // present next view
                    showClimaxView = true
                }
                .transition(.move(edge: .bottom))
            }
            NavigationLink(
                destination: ClimaxView(),
                isActive: $showClimaxView,
                label: {
                    EmptyView()
                })
        }
        .padding()
        .animation(.default)
        .onReceive(timer, perform: { _ in
            if timeRemaning < 6 {
                imageName = "handwashed.png"
            }
            if timeRemaning == 15 {
                showJustWashedButton = true
            }
            if timeRemaning > 0 {
                timeRemaning -= 1
            }
            if timeRemaning == 0 {
                // stop the timere here
                timer.upstream.connect().cancel()
                // show next view screen here
                showClimaxView = true
                
            }
        })
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
    
    public init() {}
}
