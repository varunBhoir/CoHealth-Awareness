import SwiftUI

public struct SlidesView: View {
    @State private var count = 0
    @State private var showNextPhraseIndex = 0
    @State private var isShowingDetailView = false
    let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    public var body: some View {
        ZStack {
            Color.black
                .edgesIgnoringSafeArea(.all)
            NavigationLink(
                destination: HomeView(),
                isActive: $isShowingDetailView) {
                EmptyView()
            }
            Text(Database.slidesPhrases[showNextPhraseIndex])
                .foregroundColor(.white)
                .font(.title)
                .bold()
        }
        .onReceive(timer) { time in
            count += 1
            if showNextPhraseIndex < (Database.slidesPhrases.count - 1) {
                withAnimation {
                    if showNextPhraseIndex == 0 {
                        if count == 4 {
                            showNextPhraseIndex += 1
                        }
                    }
                    else if showNextPhraseIndex == 1 {
                        if count == 6 {
                            showNextPhraseIndex += 1
                        }
                    }
                    else if showNextPhraseIndex == 2 {
                        if count == 10 {
                            showNextPhraseIndex += 1
                        }
                    }
                    else if showNextPhraseIndex == 3 {
                        if count == 12 {
                            showNextPhraseIndex += 1
                        }
                    }
                    else if showNextPhraseIndex == 4 {
                        if count == 14 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 5 {
                        if count == 16 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 6 {
                        if count == 17 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 7 {
                        if count == 20 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 8 {
                        if count == 21 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 9 {
                        if count == 22 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 10 {
                        if count == 24 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 11 {
                        if count == 25 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 12 {
                        if count == 26 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 13 {
                        if count == 27 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 14 {
                        if count == 28 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 15 {
                        if count == 29 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 16 {
                        if count == 33 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 17 {
                        if count == 35 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 18 {
                        if count == 37 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 19 {
                        if count == 38 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 20 {
                        if count == 39 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 21 {
                        if count == 40 {
                            showNextPhraseIndex += 1
                        }
                    } else if showNextPhraseIndex == 22 {
                        if count == 41 {
                            showNextPhraseIndex += 1
                        }
                    }
                }
            }
            else {
                if count == 45 {
                    // turn off the sound here
                    AudioPlayer.shared.StopThePlayer()
                    // turn off the timer here
                    timer.upstream.connect().cancel()
                    isShowingDetailView = true
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .onAppear {
            // play the sound
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                AudioPlayer.shared.playSound(sound: "covid-19theme", type: "mp3", noOfLoops: -1)
            }
            
        }
    }
    public init() { }
}



