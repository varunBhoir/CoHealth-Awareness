import SwiftUI



 public struct HomeView: View {
    @State private var showSheet = false
    @State private var sheet: Sheet = .variants
    
     public var body: some View {
        VStack(spacing: 25) {
            ZStack {
                Image(uiImage: #imageLiteral(resourceName: "coronavirus.png"))
                    .resizable()
                    .blur(radius: 6)
                    .scaledToFit()
                    .frame(width: 220)
                    
                Text("Covid-19")
                    .font(.system(size: 40, weight: .black))
                    .foregroundColor(.white)
            }
            Text("Learn more")
                .font(.title3)
            VStack(spacing: 12) {
                Button(action: {
                    sheet = .variants
                    showSheet = true
                }) {
                    LearnMoreLabels(colors: [Color.darkRed, Color.lightRed]) {
                        HStack {
                            Image(systemName: "6.circle")
                            
                            Text("Variants")
                        }
                    }}
                Button(action: {
                    sheet = .vaccines
                    showSheet = true
                }) {
                    LearnMoreLabels(colors: [Color.darkGreen, Color.lightGreen]) {
                        HStack {
                            Image(systemName: "13.circle")
                            Text("Vaccines")
                        }
                    }
                }
                Button(action: {
                    sheet = .statistics
                    showSheet = true
                }) {
                    LearnMoreLabels(colors: [Color.darkBlue, Color.lightBlue]) {
                        HStack {
                            Text("🌍")
                            Text("Statistics")
                        }
                    }
                }
            }
            .foregroundColor(.white)
            .font(.headline)
            HStack {
                Spacer()
                NavigationLink(
                    destination: CardsView(),
                    label: {
                        CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                            HStack(spacing: 20) {
                                Text("Go On")
                                Image(systemName: "arrow.right")
                            }
                        }
                    })
            }
            .padding(.horizontal)
        }
        .padding(.vertical)
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .sheet(isPresented: $showSheet, content: {
            showSheetView(of: sheet)
        })
    }
    public init() { }
    
    @ViewBuilder func showSheetView(of sheet: Sheet) -> some View {
        switch sheet {
        case .variants:
            VariantsView()
        case .vaccines:
            VaccinesView()
        case .statistics:
            StatisticsView()
        }
    }
    
     enum Sheet {
        case variants
        case vaccines
        case statistics
    }
}

public struct LearnMoreLabels<Content: View>: View {
    let colors: [Color]
    let content: () -> Content
    public var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .fill(LinearGradient(gradient: Gradient(colors: colors), startPoint: .leading, endPoint: .trailing))
            content()
        }
        .frame(width: 250, height: 50)
        .shadow(color: .gray, radius: 5, x: 2, y: 4)

    }
    
    init(colors: [Color], @ViewBuilder content: @escaping () -> Content) {
        self.colors = colors
        self.content = content
    }
}





