import SwiftUI


public struct VaccinesView: View {
    public var body: some View {
        VStack(spacing: 50) {
            VStack {
                ZStack {
                    Image(uiImage: #imageLiteral(resourceName: "coronavirus.png"))
                        .resizable()
                        .blur(radius: 4)
                        .scaledToFit()
                        .frame(width: 130)
                    
                    Text("Vaccines")
                        .font(.system(size: 25, weight: .black))
                        .foregroundColor(.white)
                }
                HStack {
                    Text("From raps.org")
                        .font(.headline)
                    Image(uiImage: UIImage(named: "clipboard.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40)
                }
            }
            List(Database.vaccines, id: \.name) { vaccine in
                VStack(alignment: .leading, spacing: 5) {
                    Text(vaccine.name)
                        .font(.title2)
                        .bold()
                    Text(vaccine.origin)
                        .italic()
                    Text(vaccine.vaccineType)
                        .foregroundColor(.gray)
                        .padding(.top, 5)
                }
            }
        }
        .padding()
    }
    public init() {}
}

