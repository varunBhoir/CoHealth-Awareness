import SwiftUI

public struct StatisticsView: View {
    @State private var currentStats: [Double] = []
    let casesIndia: [Double] = [11039, 12899, 12408, 11713, 12059, 11831, 9110, 11067, 12923, 9309, 12143, 12194, 11649, 9121, 11610, 12881, 13193, 13993, 14264, 14199, 10584, 13742, 16738, 16577, 16488, 16752, 15510, 12286, 14989, 17407, 16838, 18284, 18754, 18599, 15388, 17921, 22854, 23285, 24882, 25320, 26291, 24492, 28903, 35871, 39726, 40953, 43846, 46951, 40715, 47262, 53476, 59118, 62258, 62714, 68020, 56211, 53480, 72330, 81466, 89129, 93249, 103558, 96982, 115736, 126789, 131968, 145384]
    let casesUS: [Double] = [115317, 121621, 123961, 134390, 103977, 89630, 90298, 95621, 95165, 105741, 99616, 87106, 65010, 54184, 62711, 70117, 69597, 79597, 71519, 57069, 56208, 72255, 74717, 77492, 76971, 64428, 51197, 58888, 57052, 67184, 68045, 66445, 58191, 40939, 45014, 57698, 57906, 62462, 61317, 53120, 38212, 56649, 53946, 59121, 60525, 61620, 55369, 33760, 51577, 53588, 86951, 67452, 77314, 62078, 43695, 69420, 61240, 67029, 79034, 69822, 62974, 34932, 77794, 61958, 75038, 79878, 82698]
    let casesUK: [Double] = [16906, 19215, 20734, 19204, 18363, 15904, 14138, 12441, 13077, 13543, 15198, 13355, 10991, 9776, 10636, 12760, 12095, 12099, 10453, 9835, 10659, 8523, 9947, 10020, 8588, 7457, 6055, 5462, 6411, 6420, 6644, 6024, 6118, 5260, 4823, 5869, 6021, 6835, 6684, 5617, 4695, 5130, 5363, 5793, 6332, 4872, 5639, 5356, 5407, 5417, 5626, 6277, 6235, 3909, 3947, 4783, 4071, 4115, 4565, 3422, 3424, 2405, 2831, 2404, 2797, 3124, 3300]
    @State private var selction: Country = .india
    
    public var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Text("🌍")
                Text("Statistics")
            }
            .font(.title)
            Picker(selection: $selction, label: Text("Picker")) {
                Text("India").tag(Country.india)
                Text("USA").tag(Country.usa)
                Text("UK").tag(Country.uk)
            }.pickerStyle(SegmentedPickerStyle())
            HStack {
                Text("Cases")
                    .bold()
                    .rotationEffect(.degrees(-90))
                VStack {
                        LineView(data: getStats(of: selction))
                            .padding()
                    
                    VStack {
                        Text("February - March - April")
                        Text("Months")
                            .bold()
                    }
                }
            }
        }
        .animation(.linear)
        .padding()
    }
    
    public init() {}
    
    func getStats(of country: Country) -> [Double] {
        switch country {
        case .india:
            return casesIndia
        case .usa:
            return casesUS
        case .uk:
            return casesUK
        }
    }
    
    enum Country {
        case india
        case usa
        case uk
    }
}




struct LineView: View {
    var data: [(Double)]

    public var body: some View {
        GeometryReader{ geometry in
            VStack(alignment: .leading, spacing: 8) {
                Line(data: self.data,
                     frame: .constant(CGRect(x: 0, y: 0, width: geometry.frame(in: .local).width , height: geometry.size.height))
                     
                ).padding(.horizontal)
            }
        }
    }
}

struct Line: View {
    var data: [(Double)]
    @Binding var frame: CGRect

    let padding:CGFloat = 30
    
    var stepWidth: CGFloat {
        if data.count < 2 {
            return 0
        }
        return frame.size.width / CGFloat(data.count-1)
    }
    var stepHeight: CGFloat {
        var min: Double?
        var max: Double?
        let points = self.data
        if let minPoint = points.min(), let maxPoint = points.max(), minPoint != maxPoint {
            min = minPoint
            max = maxPoint
        }else {
            return 0
        }
        if let min = min, let max = max, min != max {
            if (min <= 0){
                return (frame.size.height-padding) / CGFloat(max - min)
            }else{
                return (frame.size.height-padding) / CGFloat(max + min)
            }
        }
        
        return 0
    }
    var path: Path {
        let points = self.data
        return Path.lineChart(points: points, step: CGPoint(x: stepWidth, y: stepHeight))
    }
    
    public var body: some View {
        
        ZStack {

            self.path
                .stroke(Color.green ,style: StrokeStyle(lineWidth: 3, lineJoin: .round))
                .rotationEffect(.degrees(180), anchor: .center)
                .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                .animation(.linear)
                .drawingGroup()
        }
    }
}

extension Path {
    
    static func lineChart(points:[Double], step:CGPoint) -> Path {
        var path = Path()
        if (points.count < 2){
            return path
        }
        guard let offset = points.min() else { return path }
        let p1 = CGPoint(x: 0, y: CGFloat(points[0]-offset)*step.y)
        path.move(to: p1)
        for pointIndex in 1..<points.count {
            let p2 = CGPoint(x: step.x * CGFloat(pointIndex), y: step.y*CGFloat(points[pointIndex]-offset))
            path.addLine(to: p2)
        }
        return path
    }
}
