import SwiftUI


public struct VariantsView: View {
    public var body: some View {
        VStack(spacing: 50) {
            VStack {
                ZStack {
                    Image(uiImage: #imageLiteral(resourceName: "coronavirus.png"))
                        .resizable()
                        .blur(radius: 4)
                        .scaledToFit()
                        .frame(width: 130)
                        
                    Text("Variants")
                        .font(.system(size: 25, weight: .black))
                        .foregroundColor(.white)
                }
                Text("From cdc.gov")
                    .font(.headline)
            }
            List(Database.newVariants, id: \.name) { variant in
                    
                    VStack(alignment: .leading, spacing: 5) {
                        Text(variant.name)
                            .font(.title2)
                            .bold()
                        Text(variant.firstDetected)
                            .italic()
                        Text(variant.predictedAttributes)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                
            }
        }
        .padding()
    }
    public init() {}
}
