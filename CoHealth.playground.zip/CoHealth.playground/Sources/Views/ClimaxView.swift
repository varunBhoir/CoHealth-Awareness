import SwiftUI



struct Movement {
    var x: CGFloat
    var y: CGFloat
    var z: CGFloat
    var opacity: Double
}

public struct ClimaxView: View {
    @State var animate = [false]
    @State var finishedAnimationCouter = 0
    @State var counter = 0
    @State var showAboutCreatorView = false
    
    public var body: some View {
        VStack {
            Spacer()
            Text("👏")
                .font(.system(size: 100))
            ZStack{
                ForEach(finishedAnimationCouter...counter, id:\.self){ i in
                    ConfettiContainer(animate:$animate[i], finishedAnimationCouter:$finishedAnimationCouter, num: 40)
                }
            }
            VStack(spacing: 20) {
                Text("Great job !!!")
                    .font(.headline)
                    .padding()
                Text("Now you have know how to protect yourself and others from coronavirus disease.")
                Text("Together, forward in the fight against COVID-19")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                HStack {
                    Spacer()
                    Button(action: {
                        // first turn off the audio
                        AudioPlayer.shared.StopThePlayer()
                        // then present the about creator view
                        showAboutCreatorView = true
                    }, label: {
                        CustomButton(colors: [Color.darkBlue, Color.lightBlue]) {
                            Text("About Creator")
                        }
                    })
                    NavigationLink(
                        destination: ProfileView(),
                        isActive: $showAboutCreatorView,
                        label: {
                            EmptyView()
                        })
                }
                .padding()
            }
            
        }
        .onAppear {
            AudioPlayer.shared.playSound(sound: "applause", type: "mp3")
            animate[counter].toggle()
            animate.append(false)
            counter += 1
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                animate[counter].toggle()
                animate.append(false)
                counter += 1
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                animate[counter].toggle()
                animate.append(false)
                counter += 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

struct ConfettiContainer: View {
    @Binding var animate:Bool
    @Binding var finishedAnimationCouter:Int

    var num:Int
    
    var body: some View{
        ZStack{
            ForEach(0...num-1, id:\.self){ _ in
                Confetti(animate: $animate, finishedAnimationCouter:$finishedAnimationCouter)
            }
        }
        .onChange(of: animate){_ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
                finishedAnimationCouter+=1
            }
        }
    }
}

struct Confetti: View {
    @Binding var animate:Bool
    @Binding var finishedAnimationCouter:Int
    @State var movement = Movement(x: 0, y: 0, z: 1, opacity: 0)
    

    var body: some View{
        ConfettiView()
            .frame(width: 50, height: 50, alignment: .center)
            .offset(x: movement.x, y: movement.y)
            .scaleEffect(movement.z)
            .opacity(movement.opacity)
            .onChange(of: animate) { _ in
                withAnimation(Animation.easeOut(duration: 0.4)) {
                    movement.opacity = 1
                    movement.x = CGFloat.random(in: -500...500)
                    movement.y = -300 * CGFloat.random(in: 0.5...1.5)
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                    withAnimation(Animation.easeIn(duration: 3)) {
                        movement.y = 200
                        movement.opacity = 0.0
                    }
                }
        }
    }
}


struct ConfettiView: View {
    @State var animate = false
    @State var xSpeed = Double.random(in: 0.7...2)
    @State var zSpeed = Double.random(in: 1...2)
    @State var anchor = CGFloat.random(in: 0...1).rounded()
    let colors: [Color] = [.blue, .darkBlue, .darkGreen, .darkRed, .lightRed, .lightBlue, .lightGreen, .gray, .green, .orange, .pink, .purple, .red, .yellow]
    
    var body: some View {
        Rectangle()
            .fill(colors.randomElement() ?? Color.pink)
            .frame(width: 20, height: 20, alignment: .center)
            .onAppear(perform: { animate = true })
            .rotation3DEffect(.degrees(animate ? 360:0), axis: (x: 1, y: 0, z: 0))
            .animation(Animation.linear(duration: xSpeed).repeatForever(autoreverses: false), value: animate)
            .rotation3DEffect(.degrees(animate ? 360:0), axis: (x: 0, y: 0, z: 1), anchor: UnitPoint(x: anchor, y: anchor))
            .animation(Animation.linear(duration: zSpeed).repeatForever(autoreverses: false), value: animate)
    }
}
