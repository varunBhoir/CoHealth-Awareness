
import SwiftUI

public struct ProfileView: View {
    public var body: some View {
        VStack(spacing: 150) {
            HStack {
                Image(uiImage: UIImage(named: "me.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .clipShape(Circle())
                    .frame(width: 200)
                    .overlay(Circle().stroke(Color.white, lineWidth: 5).shadow(color: .gray, radius: 5))
                    .padding()
                VStack(alignment: .leading) {
                    Text("Hello!")
                        .font(.headline)
                    Text("I'm Varun from 🇮🇳")
                        .font(.headline)
                    Text("I'm 20 and I love SwiftUI. I'm an undergraduate student currently studying Electronics and Telecommunication Engineering")
                        .fixedSize(horizontal: false, vertical: true)
                        .foregroundColor(.gray)
                        .padding(.top)
                }
            }
            Text("Note: I know my current field is kinda different 😅")
                .foregroundColor(.gray)
        }
        .padding()
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}


