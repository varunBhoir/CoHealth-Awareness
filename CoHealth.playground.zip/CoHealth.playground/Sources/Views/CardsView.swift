import SwiftUI

public struct CardsView: View {
    @State private var startsScaling = false
    public var body: some View {
        GeometryReader { geometry in
            ScrollView(showsIndicators: false) {
                VStack(spacing: 30) {
                    NavigationLink(
                        destination: CommonMythsView(),
                        label: {
                            CardView(gradientColors: [Color.darkGreen, Color.lightGreen], text: "Common myths", imageName: "myths")
                                .frame(width: geometry.size.width, height: 150)
                                .scaleEffect(startsScaling ? 1.1 : 1)
                                .animation(
                                    Animation.easeInOut(duration: 1).repeatForever()
                                
                                )
                        })
                    NavigationLink(
                        destination: SymptomsView(),
                        label: {
                            CardView(gradientColors: [Color.darkRed, Color.lightRed], text: "Symptoms", imageName: "symptoms")
                                .frame(width: geometry.size.width, height: 150)
                        })
                    NavigationLink(
                        destination: PreventionView(),
                        label: {
                            CardView(gradientColors: [Color.darkBlue, Color.lightBlue], text: "Prevention", imageName: "shield")
                                .frame(width: geometry.size.width, height: 150)
                        })
                    NavigationLink(
                        destination: WhatAfterVaccinationView(),
                        label: {
                            CardView(gradientColors: [Color.darkGreen, Color.lightGreen], text: "What after Vaccination?", imageName: "vaccination")
                                .frame(width: geometry.size.width, height: 150)
                        })  
                }
            }
            .onAppear {
                startsScaling = true
            }
            
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
    public init() {}
}

struct CardView: View {
    let colors: [Color]
    let text: String
    let imageName: String
    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 10)
                .fill(LinearGradient(gradient: Gradient(colors: [colors[0], colors[1]]), startPoint: .top, endPoint: .bottom))
                .shadow(color: .gray, radius: 10, x: 3, y: 7)
            GeometryReader { innerGeo in
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .frame(width: innerGeo.size.width / 3)
                            .shadow(color: .gray, radius: 10, x: 3, y: 7)
                        Image(uiImage: UIImage(named: imageName)!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: innerGeo.size.width / 3.5)
                    }
                    Spacer()
                    Text(text)
                        .foregroundColor(.white)
                        .font(.largeTitle)
                        .bold()
                        .multilineTextAlignment(.center)
                        .frame(width: innerGeo.size.width / 2, alignment: .leading)
                }
            }
        }
        .padding()
    }
    init(gradientColors: [Color], text: String, imageName: String) {
        colors = gradientColors
        self.text = text
        self.imageName = imageName
    }
}



