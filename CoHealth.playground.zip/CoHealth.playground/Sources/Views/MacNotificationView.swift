import SwiftUI

 public struct MacNotificationView: View {
    @State private var startsScaling = false
    @State private var macNotificationView = false
    @State private var showSlidesView = false
    public var body: some View {
        NavigationView {
            VStack {
                Text("")
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            withAnimation(.default) {
                                macNotificationView = true
                            }
                        }
                    }
                if macNotificationView {
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.black.opacity(0.65))
                        VStack(alignment: .leading) {
                            HStack {
                                Image(uiImage: UIImage(named: "earth.png")!)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 40)
                                    .background(LinearGradient(gradient: Gradient(colors: [Color.darkBlue, Color.lightBlue]), startPoint: .top, endPoint: .bottom))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                Text("WORLD")
                                Spacer()
                                NavigationLink(
                                    destination: SlidesView(),
                                    isActive: $showSlidesView,
                                    label: {
                                        EmptyView()
                                    })
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 18))
                                    .foregroundColor(.white)
                                    .padding(10)
                                    .scaleEffect(startsScaling ? 1 : 1)
                                    .onAppear {
                                            startsScaling = true
                                    }
                                    .animation(
                                        Animation.easeInOut(duration: 1).repeatCount(5)

                                    )
                                    .onTapGesture {
                                        // first turn off the audio here
                                        AudioPlayer.shared.StopThePlayer()
                                        // then display the slides view by navigation link
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                            showSlidesView = true
                                        }
                                    }
                            }
                            Text("The world needs you")
                                .bold()
                                .font(.system(size: 18))
                        }
                        .foregroundColor(.white)
                        .padding()
                        
                    }
                    
                    .frame(width: 410, height: 110)
                    .transition(.asymmetric(insertion: .move(edge: .trailing), removal: .opacity))
                    .animation(.easeOut)
                    .onAppear {
                        AudioPlayer.shared.playSound(sound: "mailreceived", type: "mp3")
                    }
                }
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    public init() { }
}
