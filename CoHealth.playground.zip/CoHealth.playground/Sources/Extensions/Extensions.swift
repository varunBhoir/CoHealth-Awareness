import SwiftUI

public extension Color {
    static let lightRed: Color = Color(red: 238/255, green: 79/255, blue: 23/255)
    static let darkRed: Color = Color(red: 224/255, green: 29/255, blue: 71/255)
    static let lightGreen: Color = Color(red: 15/255, green: 201/255, blue: 154/255)
    static let darkGreen: Color = Color(red: 12/255, green: 146/255, blue: 73/255)
    static let lightBlue: Color = Color(red: 51/255, green: 203/255, blue: 226/255)
    static let darkBlue: Color = Color(red: 37/255, green: 110/255, blue: 225/255)
}


public extension View {
    func stacked(at position: Int, in total: Int) -> some View {
        let offset = CGFloat(total - position)
        return self.offset(CGSize(width: 0, height: offset * 10))
    }
}
