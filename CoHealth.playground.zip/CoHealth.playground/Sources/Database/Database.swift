import SwiftUI


public struct Database {
    public static let slidesPhrases: [String] = [
        "COVID-19",// 0
        "A PANDEMIC THAT CHANGED", // 1
        "THE WORLD", // 2
        "ON APRIL 15", // 3
        "GLOBAL DEATHS PASS", // 4
        "DEATHS", // 5
        "3,000,000", // 6
        "3 MILLION", // 7
        "IT", // 8
        "IS", // 9
        "THE WORST", // 10
        "PUBLIC", // 11
        "HEALTH", // 12
        "CRISIS", // 13
        "FOR", // 14
        "A", // 15
        "GENERATION", // 16
        "THE VIRUS HAS MUTATED", // 17
        "THAT MEANS", // 18
        "EVEN BIGGER", // 19
        "WAVE", // 20
        "MAY", // 21
        "BE", // 22
        "COMING" // 23
    ]
    
    public static let newVariants: [NewVariant] = [
        NewVariant(name: "B.1.526", firstDetected: "New York", predictedAttributes: "Potential reduction in neutralization by convalescent and post-vaccination sera"),
        NewVariant(name: "B.1.525", firstDetected: "New York", predictedAttributes: "Potential reduction in neutralization by monoclonal antibody treatments"),
        NewVariant(name: "P.2", firstDetected: "Brazil", predictedAttributes: "Potential reduction in neutralization by convalescent and post-vaccination sera"),
        NewVariant(name: "B.1.1.7", firstDetected: "United Kingdom", predictedAttributes: "Likely increased severity based on hospitalizations and case fatality rates"),
        NewVariant(name: "P.1", firstDetected: "Japan", predictedAttributes: "Reduced neutralization by convalescent and post-vaccination sera"),
        NewVariant(name: "B.1.351", firstDetected: "South Africa", predictedAttributes: "Moderate reduction on neutralization by convalescent and post-vaccination sera")
    ]
    
    public static let vaccines: [Vaccine] = [
        // show clipboard image
        Vaccine(name: "Comirnaty (BNT162b2)", vaccineType: "mRNA-based vaccine", origin: "Multinational"),
        Vaccine(name: "Moderna COVID‑19 Vaccine", vaccineType: "mRNA-based vaccine", origin: "US"),
        Vaccine(name: "AstraZeneca/ Covishield", vaccineType: "Adenovirus vaccine", origin: "UK"),
        Vaccine(name: "Sputnik V", vaccineType: "Recombinant adenovirus vaccine (rAd26 and rAd5)", origin: "Russia"),
        Vaccine(name: "Janssen (JNJ-78436735; Ad26.COV2.S)", vaccineType: "Non-replicating viral vector", origin: "US"),
        Vaccine(name: "CoronaVac", vaccineType: "Inactivated vaccine (formalin with alum adjuvant)", origin: "China"),
        Vaccine(name: "BBIBP-CorV", vaccineType: "Inactivated vaccine", origin: "China"),
        Vaccine(name: "EpiVacCorona", vaccineType: "Peptide vaccine", origin: "Russia"),
        Vaccine(name: "Convidicea (Ad5-nCoV)", vaccineType: "Recombinant vaccine (adenovirus type 5 vector)", origin: "China"),
        Vaccine(name: "Covaxin", vaccineType: "Inactivated vaccine", origin: "India"),
        Vaccine(name: "WIBP-CorV", vaccineType: "Inactivated vaccine", origin: "China"),
        Vaccine(name: "CoviVac", vaccineType: "Inactivated vaccine", origin: "Russia"),
        Vaccine(name: "ZF2001", vaccineType: "Recombinant vaccine", origin: "China")
    ]
    
    public static var mythCards: [Card] = [
        
        Card(prompt: "If you hold your breath for 10 seconds without discomfort, you don’t have COVID-19.", answer: .myth),
        Card(prompt: "Water or swimming does not transmit the COVID-19.", answer: .fact),
        Card(prompt: "In summer, the virus will spread more due to mosquito bites.", answer: .myth),
        Card(prompt: "Thermal scanners can detect COVID-19", answer: .myth),
        Card(prompt: "People should not wear masks while exercising.", answer: .fact),
        Card(prompt: "Drinking alcohol protect you against COVID-19.", answer: .myth),
        Card(prompt: "COVID-19 is not transmitted through houseflies.", answer: .fact)
//        Card(prompt: "5G mobile networks spread COVID-19.", answer: .myth),
//        Card(prompt: "Taking a hot bath prevent COVID-19.", answer: .myth),
//        Card(prompt: "Antibiotics can't prevent or treat COVID-19.", answer: .fact)
    
    ]
    public static let symptomPrompts: [MCQPrompt] = [
        MCQPrompt(prompt: "Select the most common symptoms of COVID-19", choices: ["Fever", "Dry cough", "Diarrhea", "tiredness" ], correctChoices: ["Fever", "Dry cough", "tiredness"]),
        MCQPrompt(prompt: "Select oral symptoms of COVID-19", choices: ["Dry mouth", "Teeth grinding", "Lesions", "COVID tongue"], correctChoices: ["Dry mouth", "Lesions", "COVID tongue"]),
        MCQPrompt(prompt: "Select the long term effects of COVID-19", choices: ["Loss of taste and smell", "Shortness of breath", "Typhoid", "Joint and muscle pain"], correctChoices: ["Loss of taste and smell", "Shortness of breath", "Joint and muscle pain"])
    ]
    
    public static let preventionPrompts: [MCQPrompt] = [
        MCQPrompt(prompt: "Select the most effective face mask types", choices: ["Three-layer surgical mask", "Neck gaiter", "Polypropylene apron mask", "N95 mask"], correctChoices: ["Three-layer surgical mask", "Polypropylene apron mask", "N95 mask"]),
        MCQPrompt(prompt: "Select appropriate actions if you are sick", choices: ["Stay home", "Go outside and have fun", "Stay in touch with your doctor", "Monitor your symptoms"], correctChoices: ["Stay home", "Stay in touch with your doctor", "Monitor your symptoms"]),
        MCQPrompt(prompt: "Select appropriate actions to prevent the spread of COVID-19", choices: ["Keep touching your eyes", "Keep a safe distance", "Wash your hands often", "Wear a face cover"], correctChoices: ["Keep a safe distance", "Wash your hands often", "Wear a face cover"])
    ]
    
    public static let afterVaccinationCards: [Card] = [
        Card(prompt: "We have to encourage and help others to register for the vaccination.", answer: .fact),
        Card(prompt: "We don't have to wear face mask in public", answer: .myth),
        Card(prompt: "We have to avoid crowded spaces and stay at least at a distance of six feet from others", answer: .fact),
        Card(prompt: "We have to avoid strenuous physical activity 2-3 days after vaccination", answer: .fact),
        Card(prompt: "We don't have to take second dose of COVID-19 vaccine", answer: .myth),
        Card(prompt: "We have to ignore COVID-19 symptoms after getting vaccinated thinking you are immune", answer: .myth)
    ]

}
 
