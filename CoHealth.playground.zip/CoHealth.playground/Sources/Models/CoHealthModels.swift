import Foundation

public struct NewVariant: Hashable {
    let name: String
    let firstDetected: String
    let predictedAttributes: String
}

public struct Vaccine: Hashable {
    let name: String
    let vaccineType: String
    let origin: String
}


public struct Card: Hashable {
   let prompt: String
   enum CardAnswers {
       case myth
       case fact
   }
   let answer: CardAnswers
}

public struct MCQPrompt {
    let prompt: String
    let choices: [String]
    let correctChoices: [String]
}

