import Foundation
import AVFoundation

public class AudioPlayer {
    
    var player : AVAudioPlayer?
    public static let shared = AudioPlayer()
    
    // to play the audio
    // sound - name of the sound which you want to play
    // ofType - extension of that sound
    public func playSound(sound: String, type: String, noOfLoops: Int = 0) {
        if let path = Bundle.main.path(forResource: sound, ofType: type) {
            do {
                player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
                player?.numberOfLoops = noOfLoops
                player?.play()
                
            }
            catch {
                print("error while playing audio -\(error)")
                
            }
        }}
    // to stop the audio
    public func StopThePlayer() {
        player?.fadeOut()
//        player?.stop()
    }
}


public extension AVAudioPlayer {
    @objc func fadeOut() {
        if volume > 0.1 {
            // Fade
            volume -= 0.1
            perform(#selector(fadeOut), with: nil, afterDelay: 0.1)
        } else {
            // Stop and get the sound ready for playing again
            stop()
//            prepareToPlay()
            volume = 1
        }
    }
}
