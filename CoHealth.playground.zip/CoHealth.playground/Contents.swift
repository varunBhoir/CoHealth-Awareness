/*:
 # CoHealth Awareness

 #### Together, forward in the fight against COVID-19
 
 ![coronavirus](coronavirus.png)

  > Most of the time, the compiler gives "out of scope" error for custom types which are already in the scope, but it build and runs perfectly fine. So, please, run it in the case that happens. I have poured my blood, sweat and tears into this playground.
 
 In 2021, the game of **Coronavirus** has changed. New "variants of concern" have emerged and spread worldwide, putting current pandemic control efforts, including vaccination, at risk of being derailed. Put simply, The virus has mutated that means even bigger wave may be coming.
 
 - The variants, B.1.427 and B.1.429, have been identified in 30 countries and most US states. In India, the two mutated strains that have combined and form a new strain.
 
 Scientists have warned that mutations can make the virus stronger. In some cases, the mutated virus can even infect those who have already recovered from coronavirus. **Some people have indeed been infected after the first dose.**
 
 **We are not going to achieve any levels of population immunity or herd immunity in 2021, " WHO's chief scientist Soumya Swaminathan warned, stressing the need to maintain physical distancing, hand-washing and mask-wearing to rein in the pandemic.**
 
 *No one is truly safe from Covid until everyone is safe*
 
 #### Life doesn’t get easier or more forgiving, we get stronger and more resilient
 
 
 Things to play around in this playground:
 
 ### COVID-19 Information
 
 Explore new variants, recommended vaccines and covid cases statistics around the world.
 
 ### Part 1: Common Myths
 
 Explore common myths which are floating around social media to prevent the spread of misinformation through interactive cards and intuitive animations.
   
 ### Part 2: Symptoms
 
 Take a look at some common and new COVID symptoms through interactive options and intuative animations
  
 ### Part 3: Prevention
 
 Understand the effectiveness of different types of masks and some self preventive techniques to prevent the spread of coronavirus with interactive options.
 
 ### Part 4: What after vaccination ?
 
 Few bunch of cards which shows what to do and not to do after getting vaccinated.
 
 ### Appreciation Time 👏🏻

 **Credits:**
 - Images from [PngTree](https://pngtree.com/so/png)
 - Audio from [Getty Images](https://www.youtube.com/watch?v=kW8PqjgImlU&list=PLcSTUwpUvagZQStHnvilrRSEgXuQTcbQR&index=4)
 - Statistics from [Postman](https://documenter.getpostman.com/view/10808728/SzS8rjbc)
 
 */
// 3 times size increased


import PlaygroundSupport
import SwiftUI


struct ContentView: View {
    var body: some View {
        MacNotificationView()
    }
}

let mainView = ContentView().frame(width: 700, height: 600)


PlaygroundPage.current.setLiveView(mainView)

